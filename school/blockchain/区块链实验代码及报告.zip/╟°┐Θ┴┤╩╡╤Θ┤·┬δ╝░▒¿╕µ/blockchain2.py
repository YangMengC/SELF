import time
import hashlib
import json


class Blobk:
    def __init__(self, msg,previous_hash) -> None:
        self.time_stmap=time.asctime()
        self.previous_hash=previous_hash
        self.msg=msg
        self.nonce=0
        self.hash=self.get_hash()

    def get_hash(self):
        date = self.time_stmap+self.msg+self.previous_hash+str(self.nonce)
        hash256=hashlib.sha256()
        hash256.update(date.encode('gb2312'))
        return hash256.hexdigest()

    def get_dict(self):
        return self.__dict__

    def Mine(self,diffculty):
        target=''
        for i in range(diffculty):
            target = target+'0'
        while(self.hash[:diffculty]!=target):
            self.nonce+=1
            self.hash=self.get_hash()
        print('Mine a new block')


class BlockChain:
    def __init__(self,diffculty) -> None:
        self.list=[]
        self.diffculty=diffculty

    def add_block(self,block):
        block.Mine(self.diffculty)
        self.list.append(block)

    def show(self):
        for obj in self.list:
            print(obj.__dict__ )

    def block_dict(self,block):
        return block.get_dict()

    def isChainValid(self):
        for i in range(1,len(self.list)):
            current_block=self.list[i]
            previous_block=self.list[i-1]
            if current_block.hash != current_block.get_hash():
                print('current hash in not equel')
                return False
            if current_block.previous_hash != previous_block.hash:
                print('previous hash in not equal')
                return False
        print('all is equal')
        return True

    def resolve_conflicts(self,chian_others):
        if (self.isChainValid() and chian_others.isChainValid()):
            if len(self.list) < len(chian_others.list):
                self.list= chian_others.list


      
test_chine=BlockChain(1)
another_chine=BlockChain(1)

test_chine.add_block(Blobk('1','0'))
another_chine.add_block(Blobk('第1代','0'))

for i in range(5):
    test_chine.add_block(Blobk(f'{i}th iteration',test_chine.list[(len(test_chine.list))-1].hash))
    another_chine.add_block(Blobk(f'{i}th iteration',another_chine.list[(len(another_chine.list))-1].hash))
    
for i in range(6,10):
    another_chine.add_block(Blobk(f'{i}th iteration',another_chine.list[(len(another_chine.list))-1].hash))

for i in range(8,10):
    test_chine.add_block(Blobk(f'{i}th iteration',test_chine.list[(len(test_chine.list))-1].hash))

another_chine.list[5].hash='10086'  

print('test_chine')    
print('___'*10)
test_chine.show()
print('another_chine')    
print('___'*10)
another_chine.show()

test_chine.resolve_conflicts(another_chine)

print('after resolve_conflicts,test_chine')    
print('___'*10)
test_chine.show()
print('after resolve_conflicts,another_chine')    
print('___'*10)
another_chine.show()